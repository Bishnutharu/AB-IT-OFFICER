# **App Name**: EduVerse

## Core Features:

- Secure Login: User authentication with username/password, including 'Forgot Password' functionality.
- User Registration: Allow new users (schools) to register with school details (logo, name, address, contact info) and admin username/password.
- Fee Structure Management: Define and manage fee structures for different classes (admission, monthly, activity fees) with session and date tracking.
- Student Profile: Store student information including registration details, personal information, parent details, fee payment history and the option to add an image.
- Fee Receipt Generation: Generate fee receipts with details (receipt number, date, fee types, amount, total). Provides options to print, create new, and save receipts.
- Teacher Management: Maintain teacher information (name, address, contact details, salary, subject, image, ID).
- Advanced Search & Reporting: Search student/teacher records by name/ID/Reg No and display results in an Excel-compatible table format.

## Style Guidelines:

- Primary color: A vibrant cyan (#00FFFF) for a modern and technological feel.
- Background color: Dark navy blue (#191970), desaturated to create a professional contrast with the bright primary color.
- Accent color: Magenta (#FF00FF) for highlights and call-to-action buttons, complementing the primary cyan.
- Font pairing: 'Space Grotesk' (sans-serif) for headlines and 'Inter' (sans-serif) for body text to maintain readability and a tech-forward look.
- Use a consistent set of modern icons for navigation and key actions within the app.
- Maintain a clean, card-based layout to display key data. Structure pages in distinct blocks, similar to the dashboard example image, to promote quick comprehension.
- Use subtle transitions and animations to enhance user experience and provide visual feedback.