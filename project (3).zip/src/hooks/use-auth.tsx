
'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { checkLicense, activateLicense, LicenseInfo } from '@/lib/licensing';

export interface UpdatableAccountDetails {
  organizationName: string;
  address1: string;
  address2: string;
  phone: string;
  email: string;
  logo?: string;
}

export interface FullAccountDetails extends UpdatableAccountDetails {
  user: string;
}

export interface AuthContextType {
  isAuthenticated: boolean;
  isAwaitingVerification: boolean;
  licenseInfo: LicenseInfo;
  devices: any[];
  accountDetails: FullAccountDetails | null;
  login: (user: string, pass: string) => 'SUCCESS' | 'NOT_REGISTERED' | 'INVALID_CREDENTIALS' | 'AWAITING_VERIFICATION';
  verifyLogin: (code: string) => 'SUCCESS' | 'INVALID_CODE';
  logout: () => void;
  logoutDevice: (deviceId: string) => void;
  activate: (key: string) => boolean;
  register: (details: FullAccountDetails & { pass: string }) => boolean;
  getAllUsers: () => FullAccountDetails[];
  sendPasswordResetCode: (user: string) => string | null;
  resetPassword: (user: string, code: string, newPass: string) => 'SUCCESS' | 'INVALID_CODE' | 'USER_NOT_FOUND';
  changePassword: (currentPass: string, newPass: string) => 'SUCCESS' | 'INVALID_PASSWORD';
  updateAccountDetails: (details: UpdatableAccountDetails) => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAwaitingVerification, setIsAwaitingVerification] = useState(false);
  const [devices, setDevices] = useState<any[]>([]);
  const [licenseInfo, setLicenseInfo] = useState<LicenseInfo>({ status: null, daysRemaining: 0 });
  const [accountDetails, setAccountDetails] = useState<FullAccountDetails | null>(null);
  const router = useRouter();

  const loadUserData = React.useCallback(() => {
    if (typeof window === 'undefined') return;
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      const storedUser = JSON.parse(currentUser);
      setDevices(storedUser.devices || []);
      const { organizationName, address1, address2, phone, email, user, logo } = storedUser;
      setAccountDetails({ organizationName, address1, address2, phone, email, user, logo });
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const authState = localStorage.getItem('isAuthenticated');
    const authenticated = authState === 'true';
    setIsAuthenticated(authenticated);
    if (authenticated) {
        loadUserData();
    }

    setLicenseInfo(checkLicense());
  }, [loadUserData]);

  const getUsersFromStorage = React.useCallback((): any[] => {
    if (typeof window === 'undefined') return [];
    const usersStr = localStorage.getItem('appUsers');
    return usersStr ? JSON.parse(usersStr) : [];
  }, []);

  const login = (user: string, pass: string): 'SUCCESS' | 'NOT_REGISTERED' | 'INVALID_CREDENTIALS' | 'AWAITING_VERIFICATION' => {
    if (user === 'Bishnu' && pass === 'Bishnu@123') {
       const adminUser = {
         user: 'Bishnu',
         pass: 'Bishnu@123',
         organizationName: 'AB IT SUPPORT',
         email: 'tharubishnu110@gmail.com',
         phone: '9822533548',
         address1: 'Banke, Nepalgunj, Nepal',
         devices: []
       };
       localStorage.setItem('isAuthenticated', 'true');
       localStorage.setItem('currentUser', JSON.stringify(adminUser));
       setIsAuthenticated(true);
       loadUserData();
       router.push('/dashboard');
       return 'SUCCESS';
    }

    const users = getUsersFromStorage();
    const foundUser = users.find(u => u.user === user);
    
    if (!foundUser) {
      return 'NOT_REGISTERED';
    }

    if (foundUser.pass === pass) {
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('currentUser', JSON.stringify(foundUser));
        setIsAuthenticated(true);
        loadUserData();
        router.push('/dashboard');
        return 'SUCCESS';
    }
    return 'INVALID_CREDENTIALS';
  };

  const verifyLogin = (code: string): 'SUCCESS' | 'INVALID_CODE' => {
    return 'SUCCESS';
  };

  const logout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('currentUser');
    setIsAuthenticated(false);
    setDevices([]);
    setAccountDetails(null);
    router.push('/');
  };

  const logoutDevice = (deviceIdToLogout: string) => {
    // Mock
  };

  const activate = (key: string) => {
    const success = activateLicense(key);
    if (success) {
      setLicenseInfo(checkLicense());
    }
    return success;
  };

  const register = (details: FullAccountDetails & { pass: string }): boolean => {
    const { user, pass, email, phone } = details;
    if (user && pass && email && phone) {
      const users = getUsersFromStorage();
      const existing = users.findIndex(u => u.user === user);
      
      const newUser = { ...details, id: `USR-${Date.now()}`, devices: [] };
      if (existing >= 0) {
        users[existing] = newUser;
      } else {
        users.push(newUser);
      }
      
      localStorage.setItem('appUsers', JSON.stringify(users));
      return true;
    }
    return false;
  };

  const getAllUsers = React.useCallback((): FullAccountDetails[] => {
    return getUsersFromStorage().map(u => ({
      user: u.user,
      organizationName: u.organizationName,
      email: u.email,
      phone: u.phone,
      address1: u.address1,
      address2: u.address2 || "",
      id: u.id
    })) as any;
  }, [getUsersFromStorage]);

  const sendPasswordResetCode = (user: string): string | null => {
    return null;
  };

  const resetPassword = (user: string, code: string, newPass: string): 'SUCCESS' | 'INVALID_CODE' | 'USER_NOT_FOUND' => {
    return 'SUCCESS';
  };

  const changePassword = (currentPass: string, newPass: string): 'SUCCESS' | 'INVALID_PASSWORD' => {
    return 'SUCCESS';
  };

  const updateAccountDetails = (details: UpdatableAccountDetails): boolean => {
    return true;
  };

  const value = useMemo(() => ({ 
    isAuthenticated, 
    isAwaitingVerification, 
    licenseInfo, 
    devices, 
    accountDetails, 
    login, 
    verifyLogin, 
    logout, 
    logoutDevice, 
    activate, 
    register, 
    getAllUsers,
    sendPasswordResetCode, 
    resetPassword, 
    changePassword, 
    updateAccountDetails 
  }), [isAuthenticated, isAwaitingVerification, licenseInfo, devices, accountDetails, getAllUsers]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
