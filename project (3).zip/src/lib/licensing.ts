
export const ACTIVATION_KEY = 'X9M4Q7A2LZK8R5T6N3WJHPEYB';
export const TRIAL_DAYS = 7;

export type ActivationStatus = 'TRIAL' | 'ACTIVATED' | 'EXPIRED' | null;

export interface LicenseInfo {
    status: ActivationStatus;
    daysRemaining: number;
}

export function checkLicense(): LicenseInfo {
    if (typeof window === 'undefined') {
        return { status: null, daysRemaining: 0 };
    }

    const storedKey = localStorage.getItem('activationKey');

    if (storedKey === ACTIVATION_KEY) {
        return { status: 'ACTIVATED', daysRemaining: Infinity };
    }

    const installDateStr = localStorage.getItem('installDate');
    if (!installDateStr) {
        localStorage.setItem('installDate', new Date().toISOString());
        return { status: 'TRIAL', daysRemaining: TRIAL_DAYS };
    }

    const installDate = new Date(installDateStr);
    const today = new Date();
    const timeDiff = today.getTime() - installDate.getTime();
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
    
    const remaining = TRIAL_DAYS - daysDiff;

    if (remaining <= 0) {
        return { status: 'EXPIRED', daysRemaining: 0 };
    }

    return { status: 'TRIAL', daysRemaining: remaining };
}

export function activateLicense(key: string): boolean {
    if (key === ACTIVATION_KEY) {
        localStorage.setItem('activationKey', key);
        return true;
    }
    return false;
}

    