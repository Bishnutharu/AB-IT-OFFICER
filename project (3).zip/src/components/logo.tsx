import { cn } from "@/lib/utils";
import { Cpu } from "lucide-react";

export function Logo({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className="bg-primary p-1.5 rounded-lg shadow-[0_0_15px_rgba(59,130,246,0.5)]">
        <Cpu className="h-6 w-6 text-white" />
      </div>
      <span className="text-xl font-bold font-headline tracking-tight text-white">
        AB IT <span className="text-primary">SUPPORT</span>
      </span>
    </div>
  );
}