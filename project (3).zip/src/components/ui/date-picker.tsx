"use client"

import * as React from "react"
import { format } from "date-fns"
import { Calendar as CalendarIcon } from "lucide-react"
import { SelectSingleEventHandler } from "react-day-picker"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

export type DatePickerProps = {
  value?: Date;
  onChange?: (date: Date | undefined) => void;
  placeholder?: string;
};

export function DatePicker({ value: controlledValue, onChange: onControlledChange, placeholder }: DatePickerProps) {
  const [uncontrolledValue, setUncontrolledValue] = React.useState<Date>();

  // If onControlledChange is provided, we treat this as a controlled component
  const isControlled = onControlledChange !== undefined;
  const value = isControlled ? controlledValue : uncontrolledValue;

  const handleSelect: SelectSingleEventHandler = (day) => {
    if (isControlled && onControlledChange) {
      onControlledChange(day);
    } else {
      setUncontrolledValue(day);
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant={"outline"}
          className={cn(
            "w-full justify-start text-left font-normal border-white/10 bg-background/50",
            !value && "text-muted-foreground"
          )}
        >
          <CalendarIcon className="mr-2 h-4 w-4" />
          {value ? format(value, "PPP") : <span>{placeholder ?? 'Pick a date'}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={value}
          onSelect={handleSelect}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  );
}
