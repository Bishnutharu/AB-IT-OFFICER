
"use client";

import { useState } from "react";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { 
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { 
  Network, 
  ShieldCheck, 
  Monitor, 
  ArrowRight, 
  CheckCircle2, 
  MessageSquare,
  Phone,
  Lock,
  Wrench,
  Database,
  LifeBuoy,
  Clock,
  Star,
  ChevronDown,
  Facebook,
  Instagram,
  Mail,
  MessageCircle,
  Quote,
  User
} from "lucide-react";
import Link from "next/link";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function HomePage() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    message: ''
  });

  const heroBg = PlaceHolderImages.find(img => img.id === 'hero-bg');

  const services = [
    { icon: <Wrench />, title: "Hardware Repair", desc: "Expert component-level diagnostics and professional repairs." },
    { icon: <Network />, title: "Network Setup", desc: "Enterprise-grade routing, switching, and fiber optics." },
    { icon: <LifeBuoy />, title: "IT Support", desc: "Dedicated 24/7 remote and on-site technical assistance." },
    { icon: <Database />, title: "Data Recovery", desc: "Advanced retrieval solutions for critical business data." },
    { icon: <ShieldCheck />, title: "Network Security", desc: "Comprehensive surveillance and cybersecurity protection." },
  ];

  const testimonials = [
    { id: 'testimonial-1', name: "Anita Chaudhary", role: "CEO, TechFlow", text: "AB IT Support transformed our office connectivity. Their response time is unmatched in the industry. Highly professional and efficient." },
    { id: 'testimonial-2', name: "Bishnu Tharu", role: "IT Manager", text: "Professional, reliable, and secure. They handled our complex server migration without a single minute of downtime. Absolutely stellar service." },
    { id: 'testimonial-3', name: "Ram Prasad Tharu", role: "Business Owner", text: "The CCTV surveillance system they installed provides us with peace of mind. The remote monitoring features are exactly what we needed." },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.email || !formData.message) {
      toast({ variant: 'destructive', title: 'Error', description: 'Please fill in the required fields.' });
      return;
    }

    const newLead = {
      id: `LEAD-${Date.now()}`,
      type: 'client',
      category: 'Contact Request',
      name: `${formData.firstName} ${formData.lastName}`,
      email: formData.email,
      contact: formData.phone,
      address: 'Online Inquiry',
      message: formData.message,
      setupDate: new Date().toISOString(),
      isNew: true
    };

    const existingRecords = JSON.parse(localStorage.getItem('dashboardRecords') || '[]');
    localStorage.setItem('dashboardRecords', JSON.stringify([...existingRecords, newLead]));

    toast({
      title: "Request Submitted",
      description: "Our engineers will contact you shortly.",
    });

    setFormData({ firstName: '', lastName: '', phone: '', email: '', message: '' });
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Top Banner */}
      <div className="bg-[#0f172a] text-white py-2 text-xs font-semibold px-4 hidden md:block">
        <div className="container mx-auto flex justify-between items-center">
          <span>Enterprise Computer Hardware & Network Technician Service</span>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> 9822533548</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto flex h-20 items-center justify-between px-4">
          <Logo />
          <nav className="hidden lg:flex items-center gap-8 text-sm font-semibold text-slate-600">
            <Link href="#services" className="hover:text-primary transition-colors">Services</Link>
            <Link href="#about" className="hover:text-primary transition-colors">About</Link>
            <Link href="#portfolio" className="hover:text-primary transition-colors">Portfolio</Link>
            <Link href="#contact" className="hover:text-primary transition-colors">Contact</Link>
            <Link href="/support" className="hover:text-primary transition-colors text-primary font-bold">24/7 Support</Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button asChild className="bg-[#f97316] hover:bg-[#ea580c] text-white font-bold rounded-md px-6 shadow-md">
              <Link href="/login">Client Portal</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative flex flex-col lg:flex-row min-h-[750px] overflow-hidden group">
          <div className="absolute inset-0 z-0 bg-slate-900 overflow-hidden">
             <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/50 to-transparent z-10" />
             <div className="w-full h-full animate-background-slide opacity-80 transition-transform duration-1000 group-hover:scale-110">
                {heroBg && (
                  <img 
                    src={heroBg.imageUrl} 
                    alt="AB IT Support Technician" 
                    className="w-full h-full object-cover" 
                    data-ai-hint={heroBg.imageHint}
                  />
                )}
             </div>
          </div>

          <div className="flex-1 relative z-20 p-12 lg:p-24 flex flex-col justify-center text-white">
            <div className="space-y-12 max-w-4xl">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-7xl font-bold font-headline leading-tight tracking-tight drop-shadow-2xl">
                  Professional Hardware<br/>
                  & Network Solutions.
                </h1>
                <p className="text-3xl md:text-5xl font-bold text-primary italic pl-12 md:pl-32 lg:pl-48 animate-in fade-in slide-in-from-left duration-1000 delay-300">
                  Optimized. Reliable. Secure.
                </p>
              </div>
              
              <p className="text-xl md:text-2xl text-slate-200 font-medium max-w-2xl leading-relaxed opacity-90">
                Expert Technician Services for Homes & Businesses – Upgrades, Repairs, Network Setup, & Support.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-5 pt-8">
                <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-white font-bold h-16 px-12 shadow-xl shadow-primary/30 transition-all hover:scale-105 active:scale-95 text-lg">
                  <Link href="#contact">Get a Free Quote</Link>
                </Button>
                <Button asChild size="lg" className="bg-[#f97316] hover:bg-[#ea580c] text-white font-bold h-16 px-12 shadow-xl shadow-orange-500/30 transition-all hover:scale-105 active:scale-95 text-lg">
                  <Link href="#contact">Schedule Service</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16 space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold font-headline text-slate-900">Our Services</h2>
              <div className="w-16 h-1 bg-primary mx-auto rounded-full" />
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
              {services.map((service, index) => (
                <div key={index} className="flex flex-col items-center text-center space-y-4 group cursor-pointer">
                  <div className="w-16 h-16 bg-white border border-slate-100 shadow-sm rounded-xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-300">
                    {service.icon}
                  </div>
                  <h3 className="font-bold text-slate-900 group-hover:text-primary transition-colors">{service.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-medium">
                    {service.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Success Stories Section */}
        <section className="py-24 relative overflow-hidden bg-slate-50">
          <div className="container mx-auto px-4 relative z-10">
            <div className="text-center mb-16 space-y-4">
              <p className="text-primary font-bold uppercase tracking-widest text-xs italic">Client Success Stories</p>
              <h2 className="text-3xl md:text-4xl font-bold font-headline text-slate-900">What Our Partners Say</h2>
              <div className="w-24 h-1.5 bg-primary/20 mx-auto rounded-full overflow-hidden">
                <div className="w-1/2 h-full bg-primary animate-background-slide" />
              </div>
            </div>
            
            <div className="max-w-6xl mx-auto px-12">
              <Carousel 
                opts={{ align: "start", loop: true }}
                className="w-full"
              >
                <CarouselContent>
                  {testimonials.map((t, index) => {
                    const testimonialImage = PlaceHolderImages.find(img => img.id === t.id);
                    return (
                      <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3 p-4">
                        <Card className="h-full bg-white border-white/10 shadow-lg hover:shadow-2xl transition-all duration-500 group relative overflow-hidden">
                          <CardContent className="p-8 flex flex-col h-full space-y-6">
                            <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-primary/10 group-hover:border-primary/40 transition-all duration-500 mx-auto flex items-center justify-center bg-primary/5">
                              {testimonialImage?.imageUrl ? (
                                <img 
                                  src={testimonialImage.imageUrl} 
                                  alt={t.name} 
                                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                                  data-ai-hint={testimonialImage.imageHint}
                                />
                              ) : (
                                <User className="h-12 w-12 text-primary/40" />
                              )}
                            </div>
                            
                            <div className="flex-1 text-center">
                              <p className="text-slate-600 text-sm leading-relaxed font-medium italic">
                                "{t.text}"
                              </p>
                            </div>

                            <div className="pt-6 border-t border-slate-50 text-center">
                              <h4 className="font-bold text-slate-900 text-lg">{t.name}</h4>
                              <p className="text-xs text-primary font-black uppercase tracking-widest mb-3">{t.role}</p>
                              <div className="flex justify-center text-[#facc15]">
                                {[...Array(5)].map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-current" />)}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </CarouselItem>
                    );
                  })}
                </CarouselContent>
                <CarouselPrevious className="hidden md:flex" />
                <CarouselNext className="hidden md:flex" />
              </Carousel>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-white overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-16 items-start">
              <div className="space-y-12">
                <h2 className="text-3xl font-bold font-headline text-slate-900">Why Choose AB IT Support?</h2>
                <div className="grid sm:grid-cols-2 gap-x-8 gap-y-12">
                  <div className="space-y-3 group">
                    <div className="flex items-center gap-3">
                      <div className="text-primary p-2 bg-primary/5 rounded-lg group-hover:bg-primary group-hover:text-white transition-all"><Monitor className="h-5 w-5" /></div>
                      <h4 className="font-bold text-slate-900">Expertise</h4>
                    </div>
                    <p className="text-xs text-slate-500 font-medium">Experienced technicians and network architects with industry certifications.</p>
                  </div>
                  <div className="space-y-3 group">
                    <div className="flex items-center gap-3">
                      <div className="text-primary p-2 bg-primary/5 rounded-lg group-hover:bg-primary group-hover:text-white transition-all"><ShieldCheck className="h-5 w-5" /></div>
                      <h4 className="font-bold text-slate-900">Reliability</h4>
                    </div>
                    <p className="text-xs text-slate-500 font-medium">Proven track record of maintaining high uptime and secure network environments.</p>
                  </div>
                </div>
              </div>

              <Card className="bg-primary shadow-2xl border-none p-4 lg:p-8 text-white">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold font-headline">Contact Us</CardTitle>
                  <CardDescription className="text-white/70">Fill out the form below for service requests.</CardDescription>
                </CardHeader>
                <form onSubmit={handleContactSubmit}>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <Input name="firstName" value={formData.firstName} onChange={handleInputChange} placeholder="First Name" className="bg-white/10 border-white/20 text-white placeholder:text-white/40 h-12" required />
                      <Input name="lastName" value={formData.lastName} onChange={handleInputChange} placeholder="Last Name" className="bg-white/10 border-white/20 text-white placeholder:text-white/40 h-12" />
                    </div>
                    <Input name="email" value={formData.email} onChange={handleInputChange} type="email" placeholder="Email Address" className="bg-white/10 border-white/20 text-white placeholder:text-white/40 h-12" required />
                    <Textarea name="message" value={formData.message} onChange={handleInputChange} placeholder="How can we help you?" className="bg-white/10 border-white/20 text-white placeholder:text-white/40 min-h-[120px]" required />
                    <Button type="submit" className="w-full bg-[#f97316] hover:bg-[#ea580c] text-white font-bold h-12 text-lg">
                      Send Request
                    </Button>
                  </CardContent>
                </form>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-[#0f172a] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-12">
            <div className="space-y-6">
              <Logo className="brightness-200" />
              <p className="text-sm text-slate-400 font-medium leading-relaxed">
                Computer Hardware and Network Technician Service for modern enterprises.
              </p>
            </div>
            <div className="space-y-6">
              <h4 className="font-bold">Social Media</h4>
              <div className="flex gap-4">
                <a href="https://www.facebook.com/bishnu.chy.9083" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-primary transition-all group"><Facebook className="h-5 w-5" /></a>
                <a href="mailto:tharubishnu110@gmail.com" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-primary transition-all group"><Mail className="h-5 w-5" /></a>
              </div>
            </div>
          </div>
          <div className="border-t border-white/5 mt-16 pt-8 text-center text-xs text-slate-500 font-bold uppercase tracking-widest">
            <p>Copyright © AB IT SUPPORT | Powered by Enterprise Systems</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
