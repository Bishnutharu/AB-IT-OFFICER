
"use client";

import { useState, useEffect, useMemo } from "react";
import { useRouter } from 'next/navigation';
import { 
  Building,
  Mail,
  Phone,
  User as UserIcon,
  Hash,
  Activity,
  Calendar,
  LogOut,
  Save,
  PlusCircle,
  Monitor,
  Cpu,
  Search,
  Settings,
  Bell,
  Eye,
  Pencil,
  Trash2,
  ArrowLeft,
  Info,
  MapPin,
  Banknote,
  Receipt,
  FileText,
  Database,
  Plus,
  Users,
  MessageSquare,
  ChevronRight,
  Clock,
  ShieldAlert,
  ShieldCheck,
  Lock,
  Globe,
  Server,
  Key,
  GlobeLock,
  LayoutGrid,
  History,
  HardDrive,
  BarChart3,
  Wifi,
  Zap,
  Fingerprint,
  Video,
  Network as NetworkIcon,
  Shield,
  Smartphone,
  Router,
  FlameKindling,
  Crosshair,
  Radar
} from "lucide-react";
import { useAuth } from '@/hooks/use-auth';
import { cn } from "@/lib/utils";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Logo } from "@/components/logo";
import { DatePicker } from "@/components/ui/date-picker";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { SidebarProvider, Sidebar, SidebarTrigger, SidebarContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarInset, SidebarHeader, SidebarFooter } from "@/components/ui/sidebar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";

const initialClientState = {
  clientId: "",
  name: "",
  category: "",
  setupDate: undefined as Date | undefined,
  contactPerson: "",
  email: "",
  contact: "",
  address: "",
};

const initialTechnicianState = {
  name: "",
  id: "",
  address: "",
  email: "",
  contact: "",
  role: "",
  salary: "",
  joiningDate: undefined as Date | undefined,
};

const initialStockState = {
  id: "", // Invoice No
  clientName: "",
  address: "",
  vatNo: "",
  issueDate: undefined as Date | undefined,
  paymentMode: "",
  sn: "1",
  hsCode: "",
  name: "", 
  qty: "",
  rate: "",
  amount: "0.00",
  items: [] as any[],
  subTotal: "0.00",
  discount: "0",
  taxableAmount: "0.00",
  vat: "0.00",
  grandTotal: "0.00",
};

const defaultSettings = {
  siteName: "AB IT SUPPORT",
  tagline: "Enterprise Computer Hardware & Network Solutions",
  copyright: "© 2024 AB IT SUPPORT | Powered by Enterprise Systems",
  language: "en",
  timezone: "NPT",
  adminEmail: "tharubishnu110@gmail.com",
  smtpHost: "smtp.abitsupport.com",
  smtpPort: "587",
  sslForced: true,
  publicRegistration: true,
  maintenanceMode: false,
  firewallEnabled: true,
  rateLimiting: true,
  ipWhitelisting: "",
  ipAddress: "192.168.1.1",
  subnetMask: "255.255.255.0",
  gateway: "192.168.1.254",
  dnsServer: "8.8.8.8, 8.8.4.4",
  ipType: "Static",
  uacEnabled: true,
  antivirusStatus: "Active",
  resolution: "1920x1080",
  soundVolume: "75",
  powerMode: "High Performance",
  wifiSsid: "AB_ENTERPRISE_WIFI",
  proxyAddress: "",
  vpnStatus: "Disconnected",
  cameraCount: "16",
  recordingSchedule: "24/7 Continuous",
  motionDetection: true,
  cctvRemoteAccess: true,
  storageLimit: "10TB",
  rdpEnabled: true,
  vlanId: "10",
  routingProtocol: "OSPF",
  bandwidthLimit: "1Gbps",
  macFiltering: "Enabled",
  firewallLevels: 10,
  firewallMode: "Aggressive",
  deepPacketInspection: true,
  zeroTrustVerification: true,
  threatIntelligence: true,
};

const ClientProfileCard = ({ client, handleInputChange, handleSelectChange, handleDateChange, handleSave, onBack, isSaving, isAdmin }: any) => (
  <Card className="border-white/10 bg-card/50 backdrop-blur-xl animate-in fade-in slide-in-from-right-4 duration-300">
    <CardHeader className="flex flex-row items-center justify-between">
      <div>
        <CardTitle className="font-headline text-primary flex items-center gap-2">
          {isAdmin ? <Building className="h-6 w-6" /> : <Lock className="h-6 w-6 text-accent" />} 
          {isAdmin ? 'Managed Client Profile' : 'My Service Profile (Read Only)'}
        </CardTitle>
        <CardDescription>
          {isAdmin 
            ? 'Administrator: You have full permissions to modify this client record.' 
            : 'Access restricted: Your profile can only be modified by a certified AB IT SUPPORT administrator.'}
        </CardDescription>
      </div>
      {isAdmin && (
        <Button variant="ghost" size="sm" onClick={onBack} className="hover:bg-white/5">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Directory
        </Button>
      )}
    </CardHeader>
    <CardContent className="space-y-6">
      {!isAdmin && (
        <div className="p-3 bg-accent/10 border border-accent/20 rounded-lg flex items-center gap-3 text-xs text-accent font-bold uppercase tracking-widest mb-4">
          <ShieldCheck className="h-4 w-4" /> Profile Locked by Administrator
        </div>
      )}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="cl-id"><Hash className="inline mr-1 h-4 w-4"/>Client ID</Label>
          <Input id="cl-id" name="clientId" readOnly={true} placeholder="CLI-2024-001" value={client.clientId || ""} className="bg-background/50 opacity-70" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="cl-cat"><Activity className="inline mr-1 h-4 w-4"/>Service Category</Label>
          {isAdmin ? (
            <Select value={client.category || ""} onValueChange={handleSelectChange('category')}>
              <SelectTrigger className="bg-background/50"><SelectValue placeholder="Select service" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Networking">Networking</SelectItem>
                <SelectItem value="Surveillance">Surveillance (CCTV)</SelectItem>
                <SelectItem value="PABX">PABX Systems</SelectItem>
                <SelectItem value="Server">Server Hosting</SelectItem>
                <SelectItem value="Enterprise Client">Enterprise Client</SelectItem>
              </SelectContent>
            </Select>
          ) : (
            <Input value={client.category || ""} readOnly className="bg-background/50" />
          )}
        </div>
        <div className="space-y-2">
          <Label htmlFor="cl-date"><Calendar className="inline mr-1 h-4 w-4"/>Installation Date</Label>
          {isAdmin ? (
            <DatePicker value={client.setupDate} onChange={handleDateChange('setupDate')} />
          ) : (
            <Input value={client.setupDate ? new Date(client.setupDate).toLocaleDateString() : 'N/A'} readOnly className="bg-background/50" />
          )}
        </div>
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="cl-name"><Building className="inline mr-1 h-4 w-4"/>Organization Name</Label>
          <Input id="cl-name" name="name" readOnly={!isAdmin} placeholder="e.g., Tech Solutions Nepal" value={client.name || ""} onChange={handleInputChange} className={cn("bg-background/50", !isAdmin && "opacity-80")} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="cl-contact-person"><UserIcon className="inline mr-1 h-4 w-4"/>Contact Person</Label>
          <Input id="cl-contact-person" name="contactPerson" readOnly={!isAdmin} placeholder="John Doe" value={client.contactPerson || ""} onChange={handleInputChange} className={cn("bg-background/50", !isAdmin && "opacity-80")} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="cl-email"><Mail className="inline mr-1 h-4 w-4"/>Contact Email</Label>
          <Input id="cl-email" name="email" type="email" readOnly={!isAdmin} value={client.email || ""} onChange={handleInputChange} className={cn("bg-background/50", !isAdmin && "opacity-80")} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="cl-phone"><Phone className="inline mr-1 h-4 w-4"/>Contact Number</Label>
          <Input id="cl-phone" name="contact" type="tel" readOnly={!isAdmin} value={client.contact || ""} onChange={handleInputChange} className={cn("bg-background/50", !isAdmin && "opacity-80")} />
        </div>
        <div className="space-y-2 md:col-span-3">
          <Label htmlFor="cl-address">Site Address</Label>
          <Input id="cl-address" name="address" readOnly={!isAdmin} placeholder="Banke, Nepalgunj, Nepal" value={client.address || ""} onChange={handleInputChange} className={cn("bg-background/50", !isAdmin && "opacity-80")} />
        </div>
      </div>
    </CardContent>
    {isAdmin && (
      <CardFooter className="gap-2">
        <Button className="bg-accent hover:bg-accent/90" onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" /> {isSaving ? 'Updating...' : 'Apply Modifications'}
        </Button>
      </CardFooter>
    )}
  </Card>
);

const StaffProfileCard = ({ technician, handleInputChange, handleDateChange, handleSave, handleAddNew, isSaving }: any) => (
  <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
    <CardHeader>
      <CardTitle className="font-headline text-primary flex items-center gap-2">
        <Monitor className="h-6 w-6" /> Staff Profile Management
      </CardTitle>
      <CardDescription>Maintain records of engineers and field technicians.</CardDescription>
    </CardHeader>
    <CardContent className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="tm-name"><UserIcon className="inline mr-1 h-4 w-4"/>Staff Name</Label>
          <Input id="tm-name" name="name" placeholder="Bishnu Tharu" value={technician.name || ""} onChange={handleInputChange} className="bg-background/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tm-id"><Hash className="inline mr-1 h-4 w-4"/>Staff ID</Label>
          <Input id="tm-id" name="id" placeholder="T-2024-001" value={technician.id || ""} onChange={handleInputChange} className="bg-background/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tm-role"><Cpu className="inline mr-1 h-4 w-4"/>Specialization</Label>
          <Input id="tm-role" name="role" placeholder="e.g., Network Architect" value={technician.role || ""} onChange={handleInputChange} className="bg-background/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tm-salary"><Banknote className="inline mr-1 h-4 w-4"/>Monthly Salary (NPR)</Label>
          <Input id="tm-salary" name="salary" type="text" inputMode="numeric" placeholder="50000" value={technician.salary || ""} onChange={handleInputChange} className="bg-background/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tm-joining-date"><Calendar className="inline mr-1 h-4 w-4"/>Joining Date</Label>
          <DatePicker value={technician.joiningDate} onChange={handleDateChange('joiningDate')} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tm-email"><Mail className="inline mr-1 h-4 w-4"/>Email</Label>
          <Input id="tm-email" name="email" type="email" placeholder="tharubishnu110@gmail.com" value={technician.email || ""} onChange={handleInputChange} className="bg-background/50" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tm-contact"><Phone className="inline mr-1 h-4 w-4"/>Phone</Label>
          <Input id="tm-contact" name="contact" type="tel" value={technician.contact || ""} onChange={handleInputChange} className="bg-background/50" />
        </div>
        <div className="space-y-2 md:col-span-3">
          <Label htmlFor="tm-address"><MapPin className="inline mr-1 h-4 w-4"/>Current Address</Label>
          <Input id="tm-address" name="address" placeholder="Banke, Nepalgunj, Nepal" value={technician.address || ""} onChange={handleInputChange} className="bg-background/50" />
        </div>
      </div>
    </CardContent>
    <CardFooter className="gap-2">
        <Button className="bg-accent hover:bg-accent/90" onClick={handleSave} disabled={isSaving}>
          <Save className="mr-2 h-4 w-4" /> {isSaving ? 'Saving...' : 'Save Staff Profile'}
        </Button>
        <Button variant="outline" onClick={handleAddNew} className="border-white/10 hover:bg-white/5">
          <PlusCircle className="mr-2 h-4 w-4"/> Add New
        </Button>
    </CardFooter>
  </Card>
);

const RecordDetailView = ({ record, onBack, onEdit, isAdmin }: any) => (
  <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={onBack} className="hover:bg-white/5">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h2 className="text-2xl font-bold font-headline text-white">{record.name || record.clientName || record.organizationName}</h2>
          <div className="flex items-center gap-2 mt-1">
            <Badge variant="outline" className="border-primary/50 text-primary uppercase text-[10px] tracking-widest">
              {record.displayType}
            </Badge>
            {record.isNew && <Badge className="bg-accent text-white text-[10px]">NEW REQUEST</Badge>}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {isAdmin && (
          <Button variant="outline" size="sm" onClick={() => onEdit(record)} className="border-white/10">
            <Pencil className="mr-2 h-4 w-4" /> Edit Managed Record
          </Button>
        )}
      </div>
    </div>

    <div className="grid lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2 border-white/10 bg-card/50 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
            <Info className="h-4 w-4" /> Data Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-x-8 gap-y-6">
          {Object.entries(record).map(([key, value]) => {
            const skipKeys = ['type', 'image', 'displayType', 'classSub', 'id', 'name', 'items', 'pass', 'devices', 'isNew'];
            if (skipKeys.includes(key)) return null;
            
            let displayValue = value;
            if (value instanceof Date) {
              displayValue = value.toLocaleDateString();
            } else if (!value) {
              displayValue = "N/A";
            } else if (typeof value === 'string' && !isNaN(Date.parse(value)) && (key.toLowerCase().includes('date') || key.toLowerCase().includes('time'))) {
              displayValue = new Date(value).toLocaleString();
            }

            const displayLabel = key
              .replace(/([A-Z])/g, ' $1')
              .replace(/^./, str => str.toUpperCase());

            return (
              <div key={key} className="space-y-1">
                <p className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">{displayLabel}</p>
                <p className="text-sm font-medium text-white/90 whitespace-pre-wrap">{displayValue as string}</p>
              </div>
            );
          })}
          {record.type === 'stock' && record.items?.length > 0 && (
            <div className="col-span-2 mt-4 space-y-4">
               <Separator className="bg-white/5" />
               <p className="text-[10px] uppercase font-bold tracking-widest text-primary">Item List Breakdown</p>
               <div className="rounded border border-white/5 overflow-hidden">
                 <Table>
                   <TableHeader className="bg-white/5">
                     <TableRow>
                       <TableHead className="text-[10px]">S.N</TableHead>
                       <TableHead className="text-[10px]">Item</TableHead>
                       <TableHead className="text-[10px]">Qty</TableHead>
                       <TableHead className="text-[10px] text-right">Amount</TableHead>
                     </TableRow>
                   </TableHeader>
                   <TableBody>
                     {record.items.map((it: any, i: number) => (
                       <TableRow key={i}>
                         <TableCell className="text-xs">{it.sn}</TableCell>
                         <TableCell className="text-xs">{it.name}</TableCell>
                         <TableCell className="text-xs">{it.qty}</TableCell>
                         <TableCell className="text-xs text-right font-mono">{it.amount}</TableCell>
                       </TableRow>
                     ))}
                   </TableBody>
                 </Table>
               </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="text-sm font-bold uppercase tracking-widest text-primary flex items-center gap-2">
            <Activity className="h-4 w-4" /> Quick Reference
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 rounded-lg bg-white/5 border border-white/5">
            <p className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground mb-1">
              {record.type === 'stock' ? 'Invoice No' : 'System ID'}
            </p>
            <p className="font-mono text-sm text-primary">{record.id}</p>
          </div>
          <div className="p-4 rounded-lg bg-white/5 border border-white/5">
            <p className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground mb-1">
              {record.type === 'stock' ? 'Payment Mode' : 'Category/Role'}
            </p>
            <p className="text-sm font-medium">{record.classSub}</p>
          </div>
          <div className="p-4 rounded-lg bg-white/5 border border-white/5">
            <p className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground mb-1">Status</p>
            <Badge className={cn(
              "border-none",
              record.isNew ? "bg-accent text-white" : "bg-primary/20 text-primary"
            )}>
              {record.isNew ? "NEW REQUEST" : "ACTIVE"}
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  </div>
);

export default function DashboardPage() {
  const auth = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [isMounted, setIsMounted] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  
  const isAdmin = auth.accountDetails?.user === 'Bishnu';
  
  const [activeTab, setActiveTab] = useState(isAdmin ? "client-profile" : "my-profile");
  const [clientViewMode, setClientViewMode] = useState<'list' | 'form'>(isAdmin ? 'list' : 'form');
  
  const [client, setClient] = useState(initialClientState);
  const [technician, setTechnician] = useState(initialTechnicianState);
  const [stock, setStock] = useState(initialStockState);
  const [settings, setSettings] = useState(defaultSettings);
  const [localData, setLocalData] = useState<any[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [searchFilters, setSearchFilters] = useState({ name: '', id: '' });
  const [selectedRecord, setSelectedRecord] = useState<any>(null);

  useEffect(() => {
    setIsMounted(true);
    setIsOnline(typeof navigator !== 'undefined' ? navigator.onLine : true);
    
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const saved = localStorage.getItem('dashboardRecords');
    if (saved) {
      setLocalData(JSON.parse(saved));
    }
    const savedSettings = localStorage.getItem('systemSettings');
    if (savedSettings) {
      const parsed = JSON.parse(savedSettings);
      setSettings(prev => ({ ...prev, ...parsed }));
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    if (isMounted) {
      localStorage.setItem('dashboardRecords', JSON.stringify(localData));
    }
  }, [localData, isMounted]);

  useEffect(() => {
    if (isMounted) {
      localStorage.setItem('systemSettings', JSON.stringify(settings));
    }
  }, [settings, isMounted]);

  useEffect(() => {
    if (auth.accountDetails) {
      setActiveTab(isAdmin ? "client-profile" : "my-profile");
      setClientViewMode(isAdmin ? 'list' : 'form');
    }
  }, [auth.accountDetails, isAdmin]);

  useEffect(() => {
    if (!isAdmin && auth.accountDetails && isMounted) {
      const storedLocal = JSON.parse(localStorage.getItem('dashboardRecords') || '[]');
      const enrichedProfile = storedLocal.find((i: any) => i.clientId === auth.accountDetails?.user && i.type === 'client');
      
      setClient(enrichedProfile || {
        clientId: auth.accountDetails.user,
        name: auth.accountDetails.organizationName || "",
        category: "Enterprise Client",
        setupDate: undefined,
        contactPerson: auth.accountDetails.user || "",
        email: auth.accountDetails.email || "",
        contact: auth.accountDetails.phone || "",
        address: auth.accountDetails.address1 || "",
      });
    }
  }, [isAdmin, auth.accountDetails, isMounted]);

  const allData = useMemo(() => {
    if (!isMounted) return [];
    
    const registeredUsers = auth.getAllUsers().map(u => ({
      ...u,
      id: u.user,
      name: u.organizationName || u.user,
      type: 'registration',
      displayType: 'Registered User',
      classSub: 'Enterprise Client'
    }));

    const mappedLocal = localData.map(item => ({
      ...item,
      displayType: item.type === 'client' ? (item.category === 'Contact Request' ? 'Lead' : 'Client Profile') : item.type === 'stock' ? 'Inventory Invoice' : 'Staff Profile',
      classSub: item.category || item.role || item.paymentMode,
    }));

    return [...registeredUsers, ...mappedLocal];
  }, [localData, auth, isMounted]);

  const clientsList = useMemo(() => {
    if (!isAdmin || !isMounted) return [];
    return allData.filter(item => item.type === 'client' || item.type === 'registration');
  }, [allData, isAdmin, isMounted]);

  const searchResults = useMemo(() => {
    if (!isAdmin || !isMounted || (!searchFilters.name && !searchFilters.id)) return [];
    return allData.filter(item => {
      const matchName = (item.name || item.clientName || "").toLowerCase().includes(searchFilters.name.toLowerCase());
      const matchId = (item.id || "").toLowerCase().includes(searchFilters.id.toLowerCase());
      return matchName || matchId;
    });
  }, [allData, searchFilters, isAdmin, isMounted]);

  const notifications = useMemo(() => {
    if (!isAdmin || !isMounted) return [];
    return localData.filter(item => item.isNew).sort((a, b) => (b.id || "").localeCompare(a.id || ""));
  }, [localData, isAdmin, isMounted]);

  useEffect(() => {
    if (isMounted && !auth.isAuthenticated) {
      router.replace('/login');
    }
  }, [auth.isAuthenticated, router, isMounted]);

  useEffect(() => {
    const q = parseFloat(stock.qty) || 0;
    const r = parseFloat(stock.rate) || 0;
    const itemAmount = (q * r).toFixed(2);
    
    const itemsTotal = stock.items.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0);
    const subTotal = itemsTotal.toFixed(2);
    
    const discPercent = parseFloat(stock.discount) || 0;
    const taxableAmountValue = itemsTotal * (1 - discPercent / 100);
    const taxableAmount = taxableAmountValue.toFixed(2);
    
    const vatValue = taxableAmountValue * 0.13;
    const vat = vatValue.toFixed(2);
    
    const grandTotal = (taxableAmountValue + vatValue).toFixed(2);

    if (
      itemAmount !== stock.amount ||
      subTotal !== stock.subTotal ||
      taxableAmount !== stock.taxableAmount ||
      vat !== stock.vat ||
      grandTotal !== stock.grandTotal
    ) {
      setStock(prev => ({
        ...prev,
        amount: itemAmount,
        subTotal,
        taxableAmount,
        vat,
        grandTotal
      }));
    }
  }, [stock.qty, stock.rate, stock.items, stock.discount, stock.amount, stock.subTotal, stock.taxableAmount, stock.vat, stock.grandTotal]);

  const handleInputChange = (setter: any) => (e: any) => {
    const { name, value, type, checked } = e.target;
    const val = type === 'checkbox' ? checked : value;
    setter((prev: any) => ({ ...prev, [name]: val }));
  };

  const handleSelectChange = (setter: any) => (key: string) => (value: string) => {
    setter((prev: any) => ({ ...prev, [key]: value }));
  };

  const handleDateChange = (setter: any) => (key: string) => (date: any) => {
    setter((prev: any) => ({ ...prev, [key]: date }));
  };

  const handleAddItem = () => {
    if (!stock.name || !stock.qty || !stock.rate) {
      toast({ variant: 'destructive', title: 'Invalid Item', description: 'Particular, Qty, and Rate are required to add an item.' });
      return;
    }
    const newItem = {
      sn: stock.sn || "1",
      hsCode: stock.hsCode || "",
      name: stock.name || "",
      qty: stock.qty || "0",
      rate: stock.rate || "0",
      amount: stock.amount || "0.00"
    };
    
    setStock(prev => ({
      ...prev,
      items: [...prev.items, newItem],
      sn: (parseInt(prev.sn || "1") + 1).toString(),
      hsCode: "",
      name: "",
      qty: "",
      rate: "",
      amount: "0.00"
    }));
  };

  const handleSaveClient = () => {
    if (!isAdmin) return;
    if (!client.name || !client.clientId) {
      toast({ variant: 'destructive', title: 'Error', description: 'Name and Client ID are required.' });
      return;
    }
    setIsSaving(true);
    setTimeout(() => {
      setLocalData(prev => {
        const index = prev.findIndex(item => item.clientId === client.clientId && item.type === 'client');
        const newRecord = { ...client, type: 'client', isNew: false };
        if (index >= 0) {
          const updated = [...prev];
          updated[index] = newRecord;
          return updated;
        }
        return [...prev, newRecord];
      });
      toast({ title: "Administrative Action", description: `${client.name}'s profile has been updated and locked for the client.` });
      setIsSaving(false);
      setClient(initialClientState);
      setClientViewMode('list');
    }, 600);
  };

  const handleSaveStaff = () => {
    if (!isAdmin) return;
    if (!technician.name || !technician.id) {
      toast({ variant: 'destructive', title: 'Error', description: 'Name and Staff ID are required.' });
      return;
    }
    setIsSaving(true);
    setTimeout(() => {
      setLocalData(prev => {
        const index = prev.findIndex(item => item.id === technician.id && item.type === 'technician');
        const newRecord = { ...technician, id: technician.id, type: 'technician', name: technician.name };
        if (index >= 0) {
          const updated = [...prev];
          updated[index] = newRecord;
          return updated;
        }
        return [...prev, newRecord];
      });
      toast({ title: "Staff Profile Updated", description: `${technician.name} record has been saved.` });
      setIsSaving(false);
      setTechnician(initialTechnicianState);
    }, 600);
  };

  const handleSaveStock = () => {
    if (!isAdmin) return;
    if (!stock.clientName || !stock.id) {
      toast({ variant: 'destructive', title: 'Error', description: 'Client name and Invoice No are required.' });
      return;
    }
    setIsSaving(true);
    setTimeout(() => {
      setLocalData(prev => {
        const index = prev.findIndex(item => item.id === stock.id && item.type === 'stock');
        const newRecord = { ...stock, type: 'stock', name: stock.clientName };
        if (index >= 0) {
          const updated = [...prev];
          updated[index] = newRecord;
          return updated;
        }
        return [...prev, newRecord];
      });
      toast({ title: "Invoice Recorded", description: `Invoice ${stock.id} has been saved.` });
      setIsSaving(false);
      setStock(initialStockState);
    }, 600);
  };

  const handleSaveSettings = () => {
    setIsSaving(true);
    setTimeout(() => {
      localStorage.setItem('systemSettings', JSON.stringify(settings));
      setIsSaving(false);
      toast({ title: "System Settings Saved", description: "All configuration changes have been applied." });
    }, 800);
  };

  const handleEditRecord = (record: any) => {
    if (!isAdmin) return;
    if (record.type === 'client' || record.type === 'registration') {
      const baseData = record.type === 'registration' 
        ? { 
            clientId: record.user || "", 
            name: record.organizationName || record.user || "",
            email: record.email || "",
            contact: record.phone || "",
            address: record.address1 || "",
            contactPerson: record.user || "",
            category: "Enterprise Client"
          }
        : record;
        
      setClient({ ...initialClientState, ...baseData });
      setClientViewMode('form');
      setActiveTab('client-profile');
    } else if (record.type === 'technician') {
      setTechnician({ ...initialTechnicianState, ...record, id: record.id || "" });
      setActiveTab('staff-profile');
    } else if (record.type === 'stock') {
      setStock({ ...initialStockState, ...record });
      setActiveTab('inventory');
    }
  };

  const handleViewRecord = (record: any) => {
    if (!isAdmin) return;
    if (record.isNew) {
      setLocalData(prev => prev.map(item => item.id === record.id ? { ...item, isNew: false } : item));
    }
    setSelectedRecord(record);
    setActiveTab('record-detail');
  };

  const handleDeleteRecord = (id: string, type: string) => {
    if (!isAdmin) return;
    if (type === 'registration') {
      toast({ variant: 'destructive', title: 'Permission Denied', description: 'System registrations cannot be deleted from here.' });
      return;
    }
    setLocalData(prev => prev.filter(item => !(item.id === id && item.type === type)));
    toast({ variant: "destructive", title: "Record Deleted" });
  };

  if (!isMounted || !auth.isAuthenticated) return null;

  const isSearching = searchFilters.name.trim() !== '' || searchFilters.id.trim() !== '';

  return (
    <SidebarProvider>
      <Sidebar className="border-r border-white/10 bg-card/80 backdrop-blur-xl">
        <SidebarHeader className="p-4"><Logo /></SidebarHeader>
        <SidebarContent>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton onClick={() => setActiveTab(isAdmin ? 'client-profile' : 'my-profile')} isActive={activeTab === 'client-profile' || activeTab === 'my-profile'}>
                {isAdmin ? <Users /> : <UserIcon />} <span>{isAdmin ? 'Managed Clients' : 'My Service Profile'}</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            {isAdmin && (
              <>
                <SidebarMenuItem>
                  <SidebarMenuButton onClick={() => setActiveTab('staff-profile')} isActive={activeTab === 'staff-profile'}>
                    <Monitor /> <span>Staff Profiles</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton onClick={() => setActiveTab('inventory')} isActive={activeTab === 'inventory'}>
                    <Receipt /> <span>Inventory Items</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton onClick={() => setActiveTab('search-report')} isActive={activeTab === 'search-report'}>
                    <Search /> <span>Registry Search</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton onClick={() => setActiveTab('system-settings')} isActive={activeTab === 'system-settings'}>
                    <Settings /> <span>Technical Panel</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </>
            )}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="p-4 border-t border-white/10">
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={cn("h-2 w-2 rounded-full", isOnline ? "bg-accent animate-pulse" : "bg-destructive")} />
              <span className="text-[10px] font-bold uppercase tracking-widest opacity-70">
                {isOnline ? "Online Service Active" : "Offline Mode Active"}
              </span>
            </div>
            <div className="flex items-center gap-3 p-2 rounded-lg bg-white/5">
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-xs font-bold">
                {auth.accountDetails?.user?.charAt(0).toUpperCase() || 'A'}
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-sm font-bold truncate">{auth.accountDetails?.organizationName || 'Admin'}</p>
                <p className="text-[10px] text-muted-foreground truncate">{auth.accountDetails?.email || 'N/A'}</p>
              </div>
            </div>
            <Button variant="ghost" className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => auth.logout()}>
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
          </div>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="bg-background relative overflow-hidden">
        <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-white/10 bg-background/80 backdrop-blur-md px-6">
          <div className="flex items-center">
            <SidebarTrigger />
            <h1 className="ml-4 text-sm font-bold uppercase tracking-widest text-primary">
              {activeTab.replace('-', ' ')}
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
            {isAdmin && (
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative hover:bg-white/5">
                    <Bell className="h-5 w-5" />
                    {notifications.length > 0 && (
                      <span className="absolute top-2 right-2 h-2 w-2 bg-accent rounded-full animate-pulse" />
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80 p-0 bg-card border-white/10 backdrop-blur-xl shadow-2xl" align="end">
                  <div className="p-4 border-b border-white/10 flex items-center justify-between bg-primary/5">
                    <h3 className="text-sm font-bold flex items-center gap-2">
                      <ShieldAlert className="h-4 w-4 text-primary" /> Administrative Alerts
                    </h3>
                    <Badge variant="outline" className="bg-primary text-white border-none h-5 px-1.5">{notifications.length}</Badge>
                  </div>
                  <ScrollArea className="h-[350px]">
                    {notifications.length > 0 ? (
                      <div className="p-2 space-y-1">
                        {notifications.map((notif) => (
                          <button
                            key={notif.id}
                            onClick={() => handleViewRecord(notif)}
                            className="w-full text-left p-4 rounded-xl hover:bg-white/5 transition-all group border border-transparent hover:border-white/5"
                          >
                            <div className="flex items-start gap-3">
                              <div className="mt-1 h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                                <MessageSquare className="h-5 w-5" />
                              </div>
                              <div className="flex-1 overflow-hidden">
                                <div className="flex items-center justify-between mb-1">
                                  <p className="text-sm font-bold truncate group-hover:text-primary transition-colors">{notif.name}</p>
                                  <span className="text-[9px] uppercase font-bold text-accent">New</span>
                                </div>
                                <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed italic opacity-80">
                                  "{notif.message || 'Client inquiry: requested infrastructure review.'}"
                                </p>
                                <div className="flex items-center gap-2 mt-2">
                                  <span className="text-[10px] text-muted-foreground opacity-50 flex items-center gap-1">
                                    <Clock className="h-2 w-2" /> Just now
                                  </span>
                                  <ChevronRight className="h-3 w-3 text-primary opacity-0 group-hover:opacity-100 transition-all translate-x-[-4px] group-hover:translate-x-0" />
                                </div>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="p-12 text-center flex flex-col items-center justify-center space-y-3 opacity-20">
                        <div className="p-3 rounded-full bg-muted">
                          <Bell className="h-8 w-8" />
                        </div>
                        <p className="text-xs font-bold uppercase tracking-widest">No new alerts</p>
                      </div>
                    )}
                  </ScrollArea>
                </PopoverContent>
              </Popover>
            )}
            <div className="h-6 w-px bg-white/10" />
            <Button variant="ghost" size="icon" className="hover:bg-white/5" onClick={() => setActiveTab('system-settings')}><Settings className="h-5 w-5" /></Button>
          </div>
        </header>

        <main className="relative z-10 p-6 md:p-10 max-w-7xl mx-auto w-full">
          {(activeTab === 'client-profile' || activeTab === 'my-profile') && (
            <div className="space-y-6">
              {isAdmin && clientViewMode === 'list' ? (
                <Card className="border-white/10 bg-card/50 backdrop-blur-xl animate-in fade-in slide-in-from-left-4 duration-300">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="font-headline text-primary flex items-center gap-2">
                        <Users className="h-6 w-6" /> Managed User Directory
                      </CardTitle>
                      <CardDescription>Comprehensive list of registered accounts. All profile changes are strictly restricted to administrators.</CardDescription>
                    </div>
                    <Button onClick={() => { setClient(initialClientState); setClientViewMode('form'); }} className="bg-primary hover:bg-primary/90">
                      <Plus className="mr-2 h-4 w-4" /> Add Managed Client
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow className="hover:bg-transparent border-white/5">
                          <TableHead>User / Org</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Contact</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Manage</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {clientsList.length > 0 ? clientsList.map(item => (
                          <TableRow key={item.id} className="border-white/5 group hover:bg-white/5">
                            <TableCell>
                              <div>
                                <p className="font-bold text-sm group-hover:text-primary transition-colors">{item.name || ""}</p>
                                <p className="text-[10px] font-mono opacity-50">{item.id || ""}</p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="border-white/10 text-[10px] uppercase font-bold tracking-widest opacity-70">
                                {item.category || (item.type === 'registration' ? 'System Auth' : 'Managed')}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs">{item.email || 'No contact provided'}</TableCell>
                            <TableCell>
                              {item.isNew ? (
                                <Badge className="bg-accent text-white text-[9px] font-bold">UNMANAGED</Badge>
                              ) : (
                                <Badge variant="secondary" className="bg-primary/10 text-primary text-[9px] font-bold border-none">MANAGED</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleViewRecord(item)}><Eye className="h-4 w-4" /></Button>
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEditRecord(item)}><Pencil className="h-4 w-4" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-20 opacity-30 italic">No registrations found in system</TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              ) : (
                <ClientProfileCard 
                  client={client} 
                  handleInputChange={handleInputChange(setClient)}
                  handleSelectChange={handleSelectChange(setClient)}
                  handleDateChange={handleDateChange(setClient)}
                  handleSave={handleSaveClient}
                  onBack={() => setClientViewMode('list')}
                  isSaving={isSaving}
                  isAdmin={isAdmin}
                />
              )}
            </div>
          )}
          
          {isAdmin && (
            <>
              {activeTab === 'staff-profile' && (
                <StaffProfileCard 
                  technician={technician}
                  handleInputChange={handleInputChange(setTechnician)}
                  handleDateChange={handleDateChange(setTechnician)}
                  handleSave={handleSaveStaff}
                  handleAddNew={() => setTechnician(initialTechnicianState)}
                  isSaving={isSaving}
                />
              )}
              {activeTab === 'inventory' && (
                <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="font-headline text-primary flex items-center gap-2">
                       <Receipt className="h-6 w-6" /> Infrastructure Billing
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div className="grid md:grid-cols-3 gap-6">
                      <div className="space-y-4 md:col-span-2">
                        <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                          <UserIcon className="h-3 w-3" /> Billing To
                        </h3>
                        <div className="grid md:grid-cols-2 gap-4">
                          <Input name="clientName" placeholder="Client Name" value={stock.clientName || ""} onChange={handleInputChange(setStock)} className="bg-background/50" />
                          <Input name="vatNo" placeholder="VAT/PAN Number" value={stock.vatNo || ""} onChange={handleInputChange(setStock)} className="bg-background/50" />
                          <Input name="address" placeholder="Address" value={stock.address || ""} onChange={handleInputChange(setStock)} className="bg-background/50 md:col-span-2" />
                        </div>
                      </div>
                      <div className="space-y-4">
                        <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                          <FileText className="h-3 w-3" /> Managed Meta
                        </h3>
                        <Input name="id" placeholder="Invoice No." value={stock.id || ""} onChange={handleInputChange(setStock)} className="bg-background/50 font-mono" />
                        <DatePicker value={stock.issueDate} onChange={handleDateChange(setStock)('issueDate')} />
                        <Select value={stock.paymentMode || ""} onValueChange={handleSelectChange(setStock)('paymentMode')}>
                          <SelectTrigger className="bg-background/50"><SelectValue placeholder="Mode" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Cash">Cash</SelectItem>
                            <SelectItem value="Cheque">Cheque</SelectItem>
                            <SelectItem value="Credit">Credit</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Separator className="bg-white/5" />

                    <div className="grid grid-cols-12 gap-4 items-end">
                      <div className="col-span-1"><Input name="sn" value={stock.sn || ""} readOnly className="bg-background/50" /></div>
                      <div className="col-span-2"><Input name="hsCode" placeholder="H.S Code" value={stock.hsCode || ""} onChange={handleInputChange(setStock)} className="bg-background/50" /></div>
                      <div className="col-span-4"><Input name="name" placeholder="Particular" value={stock.name || ""} onChange={handleInputChange(setStock)} className="bg-background/50" /></div>
                      <div className="col-span-2"><Input name="qty" type="number" placeholder="Qty" value={stock.qty || ""} onChange={handleInputChange(setStock)} className="bg-background/50" /></div>
                      <div className="col-span-2"><Input name="rate" type="number" placeholder="Rate" value={stock.rate || ""} onChange={handleInputChange(setStock)} className="bg-background/50" /></div>
                      <div className="col-span-1"><Button onClick={handleAddItem} className="w-full"><Plus className="h-4 w-4" /></Button></div>
                    </div>

                    {stock.items.length > 0 && (
                      <Table className="border border-white/5 rounded">
                        <TableHeader><TableRow><TableHead>S.N</TableHead><TableHead>Item</TableHead><TableHead>Qty</TableHead><TableHead>Rate</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                        <TableBody>
                          {stock.items.map((item, i) => (
                            <TableRow key={i}><TableCell>{item.sn || ""}</TableCell><TableCell>{item.name || ""}</TableCell><TableCell>{item.qty || ""}</TableCell><TableCell>{item.rate || ""}</TableCell><TableCell className="text-right">{item.amount || ""}</TableCell></TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}

                    <div className="flex justify-end">
                      <div className="w-full max-w-md space-y-4 bg-white/5 p-6 rounded-xl">
                        <div className="flex justify-between items-center"><Label>Sub Total</Label><span className="font-bold">{stock.subTotal || "0.00"}</span></div>
                        <div className="flex justify-between items-center"><Label>Discount (%)</Label><Input name="discount" value={stock.discount || ""} onChange={handleInputChange(setStock)} className="w-24 text-right" /></div>
                        <div className="flex justify-between items-center"><Label>Taxable Amount</Label><span className="font-bold">{stock.taxableAmount || "0.00"}</span></div>
                        <div className="flex justify-between items-center"><Label>VAT (13%)</Label><span className="font-bold">{stock.vat || "0.00"}</span></div>
                        <Separator className="bg-white/10" />
                        <div className="flex justify-between items-center text-primary"><Label className="text-lg font-bold">GRAND TOTAL (NPR)</Label><span className="text-2xl font-bold">{stock.grandTotal || "0.00"}</span></div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="gap-2">
                    <Button className="bg-accent hover:bg-accent/90" onClick={handleSaveStock} disabled={isSaving}>
                      <Save className="mr-2 h-4 w-4" /> Issue Managed Invoice
                    </Button>
                  </CardFooter>
                </Card>
              )}
              {activeTab === 'search-report' && (
                 <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                   <CardHeader>
                     <CardTitle className="font-headline text-primary flex items-center gap-2">
                       <Search className="h-6 w-6" /> System Registry
                     </CardTitle>
                   </CardHeader>
                   <CardContent className="space-y-6">
                     <div className="grid md:grid-cols-2 gap-4">
                       <Input placeholder="Filter by Name" value={searchFilters.name || ""} onChange={e => setSearchFilters(prev => ({...prev, name: e.target.value}))} className="bg-background/50" />
                       <Input placeholder="Filter by ID" value={searchFilters.id || ""} onChange={e => setSearchFilters(prev => ({...prev, id: e.target.value}))} className="bg-background/50" />
                     </div>
                     
                     {isSearching ? (
                       <Table>
                         <TableHeader>
                           <TableRow>
                             <TableHead>ID</TableHead>
                             <TableHead>Client / Entity</TableHead>
                             <TableHead>Managed Type</TableHead>
                             <TableHead className="text-right">Actions</TableHead>
                           </TableRow>
                         </TableHeader>
                         <TableBody>
                           {searchResults.length > 0 ? searchResults.map(res => (
                             <TableRow key={`${res.type}-${res.id}`}>
                               <TableCell className="font-mono text-xs">{res.id || ""}</TableCell>
                               <TableCell className="font-medium">
                                 <div className="flex items-center gap-2">
                                   {res.name || ""}
                                   {res.isNew && <Badge className="bg-accent text-white h-4 text-[8px]">UNMANAGED</Badge>}
                                 </div>
                               </TableCell>
                               <TableCell><Badge variant="outline">{res.displayType || ""}</Badge></TableCell>
                               <TableCell className="text-right">
                                 <div className="flex justify-end gap-2">
                                   <Button variant="ghost" size="sm" onClick={() => handleViewRecord(res)}><Eye className="h-4 w-4" /></Button>
                                   <Button variant="ghost" size="sm" onClick={() => handleEditRecord(res)}><Pencil className="h-4 w-4" /></Button>
                                   <Button variant="ghost" size="sm" className="text-destructive" onClick={() => handleDeleteRecord(res.id, res.type)}><Trash2 className="h-4 w-4" /></Button>
                                 </div>
                               </TableCell>
                             </TableRow>
                           )) : <TableRow><TableCell colSpan={4} className="text-center py-10 opacity-50 italic">No matching records</TableCell></TableRow>}
                         </TableBody>
                       </Table>
                     ) : (
                       <div className="flex flex-col items-center justify-center py-20 opacity-20"><Database className="h-12 w-12 mb-2" /><p>Registry Search Engine</p></div>
                     )}
                   </CardContent>
                 </Card>
              )}
              {activeTab === 'system-settings' && (
                <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold font-headline text-white">Enterprise Admin Console</h2>
                      <p className="text-sm text-muted-foreground">Modify technical permissions and global infrastructure settings.</p>
                    </div>
                    <Button className="bg-accent hover:bg-accent/90" onClick={handleSaveSettings} disabled={isSaving}>
                      <Save className="mr-2 h-4 w-4" /> {isSaving ? "Updating System..." : "Apply Global Policies"}
                    </Button>
                  </div>

                  <Tabs defaultValue="branding" className="w-full">
                    <TabsList className="bg-card/50 border border-white/10 p-1 mb-8 overflow-x-auto h-auto flex flex-wrap justify-start">
                      <TabsTrigger value="branding" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                        <LayoutGrid className="mr-2 h-4 w-4" /> Branding
                      </TabsTrigger>
                      <TabsTrigger value="network" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                        <NetworkIcon className="mr-2 h-4 w-4" /> Network
                      </TabsTrigger>
                      <TabsTrigger value="hardware" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                        <Server className="mr-2 h-4 w-4" /> Managed Hardware
                      </TabsTrigger>
                      <TabsTrigger value="permissions" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                        <Key className="mr-2 h-4 w-4" /> Permissions
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="branding" className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><LayoutGrid className="h-5 w-5 text-primary" /> Identity</CardTitle></CardHeader>
                          <CardContent className="space-y-4">
                            <div className="space-y-2">
                              <Label>Site Name</Label>
                              <Input name="siteName" value={settings.siteName || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                            </div>
                            <div className="space-y-2">
                              <Label>Tagline</Label>
                              <Input name="tagline" value={settings.tagline || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                            </div>
                            <div className="space-y-2">
                              <Label>Language</Label>
                              <Select value={settings.language || ""} onValueChange={handleSelectChange(setSettings)('language')}>
                                <SelectTrigger className="bg-background/50"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="en">English (US)</SelectItem>
                                  <SelectItem value="ne">Nepali (NP)</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </CardContent>
                        </Card>
                        <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Smartphone className="h-5 w-5 text-primary" /> Global Device Defaults</CardTitle></CardHeader>
                          <CardContent className="space-y-4">
                            <div className="space-y-2">
                              <Label>Resolution</Label>
                              <Input name="resolution" value={settings.resolution || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                            </div>
                            <div className="space-y-2">
                              <Label>Default Volume %</Label>
                              <Input name="soundVolume" type="number" value={settings.soundVolume || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                            </div>
                            <div className="space-y-2">
                              <Label>Power Policy</Label>
                              <Select value={settings.powerMode || ""} onValueChange={handleSelectChange(setSettings)('powerMode')}>
                                <SelectTrigger className="bg-background/50"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="High Performance">High Performance</SelectItem>
                                  <SelectItem value="Balanced">Balanced</SelectItem>
                                  <SelectItem value="Power Saver">Power Saver</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </TabsContent>

                    <TabsContent value="network" className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><NetworkIcon className="h-5 w-5 text-primary" /> Managed Network Config</CardTitle></CardHeader>
                          <CardContent className="space-y-4">
                            <div className="flex items-center justify-between mb-4">
                              <Label>DHCP Enabled</Label>
                              <Switch checked={settings.ipType === 'DHCP'} onCheckedChange={(val) => setSettings(p => ({...p, ipType: val ? 'DHCP' : 'Static'}))} />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>IP Address</Label>
                                <Input name="ipAddress" value={settings.ipAddress || ""} onChange={handleInputChange(setSettings)} className="bg-background/50 font-mono" />
                              </div>
                              <div className="space-y-2">
                                <Label>Subnet Mask</Label>
                                <Input name="subnetMask" value={settings.subnetMask || ""} onChange={handleInputChange(setSettings)} className="bg-background/50 font-mono" />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label>SSID Profile</Label>
                              <Input name="wifiSsid" value={settings.wifiSsid || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                            </div>
                          </CardContent>
                        </Card>
                        <Card className="border-white/10 bg-card/50 backdrop-blur-xl overflow-hidden">
                          <CardHeader className="bg-primary/10 border-b border-white/5">
                            <CardTitle className="text-lg flex items-center gap-2">
                              <Radar className="h-5 w-5 text-primary animate-pulse" /> 10-Level Deep Defense Firewall
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="p-0">
                            <div className="grid grid-cols-2 md:grid-cols-5">
                              {[
                                { l: 1, n: "Physical", i: Globe },
                                { l: 2, n: "Link", i: Router },
                                { l: 3, n: "Network", i: NetworkIcon },
                                { l: 4, n: "Transport", i: ShieldCheck },
                                { l: 5, n: "Session", i: Fingerprint },
                                { l: 6, n: "Present.", i: Monitor },
                                { l: 7, n: "Applic.", i: LayoutGrid },
                                { l: 8, n: "Human", i: Users },
                                { l: 9, n: "Policy", i: Shield },
                                { l: 10, n: "Legal", i: GlobeLock },
                              ].map((layer) => (
                                <div key={layer.l} className="p-3 border border-white/5 flex flex-col items-center justify-center text-center group hover:bg-primary/5 transition-colors">
                                  <layer.i className="h-5 w-5 text-primary mb-1 group-hover:scale-110 transition-transform" />
                                  <p className="text-[9px] font-bold uppercase tracking-tighter opacity-50">L{layer.l}</p>
                                  <p className="text-[10px] font-bold truncate w-full">{layer.n}</p>
                                </div>
                              ))}
                            </div>
                            <div className="p-4 bg-accent/5">
                               <div className="flex items-center justify-between">
                                 <Label className="text-xs">DPI Active</Label>
                                 <Switch checked={settings.deepPacketInspection || false} onCheckedChange={(val) => setSettings(p => ({...p, deepPacketInspection: val}))} />
                               </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </TabsContent>

                    <TabsContent value="hardware" className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Video className="h-5 w-5 text-primary" /> Managed Surveillance</CardTitle></CardHeader>
                          <CardContent className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>Camera Count</Label>
                                <Input name="cameraCount" type="number" value={settings.cameraCount || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                              </div>
                              <div className="space-y-2">
                                <Label>Schedule</Label>
                                <Select value={settings.recordingSchedule || ""} onValueChange={handleSelectChange(setSettings)('recordingSchedule')}>
                                  <SelectTrigger className="bg-background/50"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="24/7 Continuous">24/7 Continuous</SelectItem>
                                    <SelectItem value="Business Hours Only">Business Hours Only</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <Label>Motion Detection</Label>
                              <Switch checked={settings.motionDetection || false} onCheckedChange={(val) => setSettings(p => ({...p, motionDetection: val}))} />
                            </div>
                          </CardContent>
                        </Card>
                        <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                          <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Database className="h-5 w-5 text-primary" /> Storage & Routing</CardTitle></CardHeader>
                          <CardContent className="space-y-4">
                            <div className="space-y-2">
                              <Label>Storage Quota</Label>
                              <Input name="storageLimit" value={settings.storageLimit || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                            </div>
                            <div className="space-y-2">
                              <Label>Bandwidth Throttling</Label>
                              <Input name="bandwidthLimit" value={settings.bandwidthLimit || ""} onChange={handleInputChange(setSettings)} className="bg-background/50" />
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </TabsContent>

                    <TabsContent value="permissions" className="space-y-6">
                       <Card className="border-white/10 bg-card/50 backdrop-blur-xl">
                        <CardHeader>
                          <CardTitle className="text-lg flex items-center gap-2">
                            <Shield className="h-5 w-5 text-accent" /> Access Controls
                          </CardTitle>
                          <CardDescription>Managed permissions are strictly restricted to the Administrator.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                          <div className="flex items-center space-x-2">
                            <Switch id="reg" checked={settings.publicRegistration || false} onCheckedChange={(val) => setSettings(p => ({...p, publicRegistration: val}))} />
                            <Label htmlFor="reg">Allow New Registrations</Label>
                          </div>
                          <Separator className="bg-white/5" />
                          <div className="space-y-4">
                            <h4 className="text-sm font-bold uppercase tracking-widest text-primary">Explicit Administrator Privileges</h4>
                            <div className="grid md:grid-cols-2 gap-4">
                              {[
                                'modify_managed_profiles', 
                                'system_configuration_write', 
                                'security_policy_enforcement',
                                'infrastructure_override'
                              ].map((perm, i) => (
                                <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-accent/5 border border-accent/20">
                                  <ShieldCheck className="h-4 w-4 text-accent" />
                                  <Label className="text-[10px] font-bold uppercase">{perm.replace(/_/g, ' ')}</Label>
                                </div>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </>
          )}

          {activeTab === 'record-detail' && selectedRecord && (
            <RecordDetailView 
              record={selectedRecord} 
              isAdmin={isAdmin}
              onBack={() => setActiveTab(selectedRecord.type === 'client' || selectedRecord.type === 'registration' ? 'client-profile' : 'search-report')} 
              onEdit={(rec: any) => handleEditRecord(rec)}
            />
          )}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
