"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Lock, User, ArrowRight, ShieldCheck, UserPlus } from "lucide-react";
import Link from "next/link";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    const result = login(username, password);

    if (result === 'SUCCESS') {
      toast({ title: "Welcome Back", description: "Accessing your technical portal..." });
    } else if (result === 'AWAITING_VERIFICATION') {
      router.push('/verify');
    } else if (result === 'NOT_REGISTERED') {
      toast({ variant: "destructive", title: "Error", description: "This account is not registered. Please contact support." });
      setIsLoading(false);
    } else {
      toast({ variant: "destructive", title: "Login Failed", description: "Invalid credentials. Please try again." });
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background relative overflow-hidden px-4">
      {/* Abstract Tech Background */}
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary rounded-full blur-[120px]" />
      </div>

      <div className="w-full max-w-md relative z-10 space-y-8">
        <div className="flex flex-col items-center text-center space-y-4">
          <Logo className="scale-125 mb-4" />
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tight text-white font-headline">Enterprise Portal</h1>
            <p className="text-muted-foreground font-medium">Manage your IT infrastructure and support tickets.</p>
          </div>
        </div>

        <Card className="border-white/10 bg-card/50 backdrop-blur-xl shadow-2xl">
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-primary" /> Login to Account
            </CardTitle>
            <CardDescription>
              Enter your corporate credentials to continue.
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleLogin}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="username" 
                    placeholder="Enter username" 
                    className="pl-10 bg-background/50" 
                    required 
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link href="#" className="text-xs text-primary hover:underline font-bold uppercase tracking-widest">Forgot?</Link>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="password" 
                    type="password" 
                    placeholder="••••••••" 
                    className="pl-10 bg-background/50" 
                    required 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button type="submit" className="w-full font-bold h-12 text-base" disabled={isLoading}>
                {isLoading ? "Authenticating..." : "Access Portal"} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <div className="grid grid-cols-2 gap-4 w-full">
                <Button variant="outline" asChild className="border-white/10 hover:bg-white/5">
                  <Link href="/register">
                    <UserPlus className="mr-2 h-4 w-4" /> New Client
                  </Link>
                </Button>
                <Button variant="ghost" asChild className="hover:bg-primary/10">
                  <Link href="/support">Support</Link>
                </Button>
              </div>
            </CardFooter>
          </form>
        </Card>

        <p className="text-center text-xs text-muted-foreground">
          Protected by enterprise-grade 256-bit encryption. <br/>
          AB IT SUPPORT © 2024
        </p>
      </div>
    </div>
  );
}