"use client";

import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle
} from "@/components/ui/card";
import { 
  Mail, 
  Phone, 
  MapPin, 
  ArrowLeft, 
  ShieldCheck,
  Clock
} from "lucide-react";
import Link from "next/link";

export default function SupportPage() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Navigation */}
      <header className="border-b bg-background/95 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto flex h-20 items-center justify-between px-4">
          <Logo />
          <Button variant="ghost" asChild>
            <Link href="/" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" /> Back to Home
            </Link>
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12 md:py-20 flex flex-col items-center">
        <div className="max-w-4xl w-full space-y-12">
          
          {/* Header Info */}
          <div className="space-y-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold font-headline">Enterprise Technical <span className="text-primary">Support</span></h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Experience high-priority response times and expert resolutions for all your hardware and networking challenges. Reach out to our engineers directly.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid sm:grid-cols-2 gap-6">
            <Card className="bg-muted/30 border-white/5">
              <CardHeader className="pb-2">
                <Clock className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">24/7 Monitoring</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Continuous surveillance and networking uptime management for our enterprise clients.</p>
              </CardContent>
            </Card>
            <Card className="bg-muted/30 border-white/5">
              <CardHeader className="pb-2">
                <ShieldCheck className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">Secure Solutions</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">End-to-end encrypted surveillance and secure VPN setups designed for maximum privacy.</p>
              </CardContent>
            </Card>
          </div>

          {/* Direct Contact Card */}
          <Card className="shadow-2xl border-white/10 overflow-hidden bg-card/50">
            <CardHeader className="text-center border-b bg-muted/20 pb-8">
              <CardTitle className="text-2xl font-headline">Contact Our Experts</CardTitle>
              <p className="text-muted-foreground">Choose your preferred method of communication</p>
            </CardHeader>
            <CardContent className="p-8 md:p-12">
              <div className="grid md:grid-cols-3 gap-8">
                <a href="mailto:tharubishnu110@gmail.com" className="flex flex-col items-center text-center gap-4 group p-6 rounded-xl hover:bg-primary/5 transition-all">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                    <Mail className="h-8 w-8" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-1">Email Support</p>
                    <p className="text-lg font-medium">tharubishnu110@gmail.com</p>
                  </div>
                </a>

                <div className="flex flex-col items-center text-center gap-4 group p-6 rounded-xl hover:bg-primary/5 transition-all">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                    <Phone className="h-8 w-8" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-1">Phone Lines</p>
                    <div className="flex flex-col gap-1">
                      <a href="tel:9822533548" className="text-lg font-medium hover:text-primary transition-colors">9822533548</a>
                      <a href="tel:9742214939" className="text-lg font-medium hover:text-primary transition-colors">9742214939</a>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center text-center gap-4 group p-6 rounded-xl hover:bg-primary/5 transition-all">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                    <MapPin className="h-8 w-8" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-1">Headquarters</p>
                    <p className="text-lg font-medium">Banke, Nepalgunj, Nepal</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

        </div>
      </main>

      {/* Footer */}
      <footer className="border-t py-12 bg-card/30">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground mb-4 italic">
            "Your infrastructure, our expertise."
          </p>
          <div className="flex flex-col items-center gap-2">
            <Logo className="mb-2" />
            <p className="text-xs text-muted-foreground">
              © 2024 AB IT SUPPORT. Registered Support Email: tharubishnu110@gmail.com
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
